<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Kadai01_1Controller extends Controller
{
    //
    public function index() {
        return "Hello Laravel8 Web Application";
    }

}
